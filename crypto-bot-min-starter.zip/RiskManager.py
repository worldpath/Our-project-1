class RiskManager: pass
