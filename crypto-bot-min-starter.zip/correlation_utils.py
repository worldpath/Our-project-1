def average_pairwise_corr(x): return 0.0
