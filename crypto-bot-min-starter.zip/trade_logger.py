class TradeLogger: pass
