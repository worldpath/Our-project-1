from flask import Flask
app = Flask(__name__)

@app.route('/')
def index():
    return "Dashboard is running"

@app.route('/healthz')
def healthz():
    return "ok"
