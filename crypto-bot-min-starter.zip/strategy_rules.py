class StrategyParams: pass
