import os, time
from datetime import datetime
from strategy_rules import StrategyParams
from RiskManager import RiskManager
from correlation_utils import average_pairwise_corr
from trade_logger import TradeLogger

print("Bot starting...")
time.sleep(2)
print("Bot running.")
